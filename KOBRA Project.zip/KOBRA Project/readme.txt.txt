Welcome to Project Kobra based on the infamous Snake Game


HOW TO INSTALL THE GAME 

1. Download and install the MCB32-MSYS Tool
2. Download the zip folder than contains the game folders and extract it 
3. Connect your Chipkit to your Computer using the USB cable
4. Open the MSYS Command window and type in this  commands ". /opt/mcb32tools/environment"
5. navigate the game file using cd .. and ls commands 
6. Compile the code by using the "make" Command
7. after you compile the code, install the game code on your Chipkit using the command "make install"


HOW TO PLAY THE GAME
1. The game boots up to the main Menu
2. Toggle SW4 (the First Switch on the left) so the game could start
3. When the snake appears on your screen that means the game has started



CONTROL :
Button 1 (BTN1) : MOVE LEFT
Button 2 (BTN2) : MOVE UP
Button 3 (BTN3) : Move DOWN
Button 4 (BTN4) : Move RIGHT