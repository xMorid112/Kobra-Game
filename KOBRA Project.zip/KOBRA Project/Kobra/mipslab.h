#include <stdbool.h>

void display_init(void);
void display_string(int line, char *s); 
void display_update(void);
uint8_t spi_send_recv(uint8_t data);
void quicksleep(int cyc);
void clear_display_buffer();

extern char textbuffer[4][16];
extern const uint8_t const font[1288];

#define DISPLAY_WIDTH  128
#define DISPLAY_HEIGHT 32
#define MAX_KOBRA_LENGTH 120
#define apple_size 2

uint8_t ds[DISPLAY_HEIGHT][DISPLAY_WIDTH];

int kobra_x[MAX_KOBRA_LENGTH];
int kobra_y[MAX_KOBRA_LENGTH];

int kobra_length;
int dx, dy; 

int points;

int apple_x;
int apple_y;

extern int s1; 
extern int s2; 

int getbtns();
int getsw();
void clear_display_buffer(void);
void clear_oled_display_buffer();
void set_display_pixel(int x, int y);
void update_oled_display();
void create_first_kobra();
void automate_kobra_move();
void handle_kobra_movement();
bool check_kobra_collision();
void handle_apple_collision(int *apple_x, int *apple_y);
int random_x(void);
int random_y(void);
void display_points();