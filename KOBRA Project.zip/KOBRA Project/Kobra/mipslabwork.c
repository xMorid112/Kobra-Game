#include <stdint.h>   
#include <pic32mx.h>  
#include "mipslab.h"  
#include <stdbool.h> 

void user_isr(void) {
    return;
}

void setUp() {
    display_init();
    bool over = true; 

    while (1) {
        if (over) {
            while ((getsw() & 0x08) == 0) {
                continue; 
            }
            create_first_kobra();
            apple_x = random_x();
            apple_y = random_y();
            over = false;
        }

        while (!over) { 
            clear_oled_display_buffer();

            for (int i = 0; i < apple_size; i++) {
                set_display_pixel(apple_x, apple_y);
            }

            for (int i = 0; i < kobra_length; i++) {
                set_display_pixel(kobra_x[i], kobra_y[i]);
            }

            update_oled_display();

            quicksleep(550000); 

            handle_kobra_movement();

            automate_kobra_move();

            handle_apple_collision(&apple_x, &apple_y);

            
            if (check_kobra_collision()) {
                
                clear_oled_display_buffer();
                display_string(0, "GG Dude");
                display_string(1, "Your Points:");
                display_points();
                display_string(3, "Toggle SW4 PLS");
                display_update();
                quicksleep(100);
                points = 0;
                over = true; 
            }
        }

        
        while ((getsw() & 0x08) != 0) {
            continue;
        }
    }
}
