
#include <stdint.h>   
#include <pic32mx.h>  
#include "mipslab.h"  
#include <stdbool.h> 
#include <stdlib.h> 
	

int main(void) {
    
	SYSKEY = 0xAA996655;  
	SYSKEY = 0x556699AA;  
	while(OSCCON & (1 << 21)); 
	OSCCONCLR = 0x180000; 
	while(OSCCON & (1 << 21));  
	SYSKEY = 0x0;  
	
	
	AD1PCFG = 0xFFFF;
	ODCE = 0x0;
	TRISECLR = 0xFF;
	PORTE = 0x0;
	
	
	PORTF = 0xFFFF;
	PORTG = (1 << 9);
	ODCF = 0x0;
	ODCG = 0x0;
	TRISFCLR = 0x70;
	TRISGCLR = 0x200;
	
	
	TRISDSET = (1 << 8);
	TRISFSET = (1 << 1);
	
	
	SPI2CON = 0;
	SPI2BRG = 4;
	
	SPI2STATCLR = 0x40;
	
        SPI2CONSET = 0x40;
	
	SPI2CONSET = 0x20;
	
	SPI2CONSET = 0x8000;

    display_init();
    display_string(0, "K.O.B.R.A");
	display_string(1, "To start playing");
    display_string(2, "Toggle SW4");
    display_update();
    
	
    while (1) {
        if (getsw() & 8) {
			clear_display_buffer();
			setUp();
        } 
	}

    return 0;
}