#include <stdlib.h>
#include <stdint.h>
#include <pic32mx.h>
#include "mipslab.h"
#include <stdio.h>
#include <stdbool.h> 

#define DISPLAY_CHANGE_TO_COMMAND_MODE (PORTFCLR = 0x10)
#define DISPLAY_CHANGE_TO_DATA_MODE (PORTFSET = 0x10)

#define DISPLAY_ACTIVATE_RESET (PORTGCLR = 0x200)
#define DISPLAY_DO_NOT_RESET (PORTGSET = 0x200)

#define DISPLAY_ACTIVATE_VDD (PORTFCLR = 0x40)
#define DISPLAY_ACTIVATE_VBAT (PORTFCLR = 0x20)

#define DISPLAY_TURN_OFF_VDD (PORTFSET = 0x40)
#define DISPLAY_TURN_OFF_VBAT (PORTFSET = 0x20)

/*LAB 3*/
void quicksleep(int cyc) {
	int i;
	for(i = cyc; i > 0; i--);
}

/*LAB 3*/
uint8_t spi_send_recv(uint8_t data) {
	while(!(SPI2STAT & 0x08));
	SPI2BUF = data;
	while(!(SPI2STAT & 1));
	return SPI2BUF;
}

/*LAB 3*/
void display_init(void) {
        DISPLAY_CHANGE_TO_COMMAND_MODE;
	quicksleep(10);
	DISPLAY_ACTIVATE_VDD;
	quicksleep(1000000);
	
	spi_send_recv(0xAE);
	DISPLAY_ACTIVATE_RESET;
	quicksleep(10);
	DISPLAY_DO_NOT_RESET;
	quicksleep(10);
	
	spi_send_recv(0x8D);
	spi_send_recv(0x14);
	
	spi_send_recv(0xD9);
	spi_send_recv(0xF1);
	
	DISPLAY_ACTIVATE_VBAT;
	quicksleep(10000000);
	
	spi_send_recv(0xA1);
	spi_send_recv(0xC8);
	
	spi_send_recv(0xDA);
	spi_send_recv(0x20);
	
	spi_send_recv(0xAF);
}

/*LAB 3*/
void display_string(int line, char *s) {
	int i;
	if(line < 0 || line >= 4)
		return;
	if(!s)
		return;
	
	for(i = 0; i < 16; i++)
		if(*s) {
			textbuffer[line][i] = *s;
			s++;
		} else
			textbuffer[line][i] = ' ';
}

/*LAB 3*/
void display_update(void) {
	int i, j, k;
	int c;
	for(i = 0; i < 4; i++) {
		DISPLAY_CHANGE_TO_COMMAND_MODE;
		spi_send_recv(0x22);
		spi_send_recv(i);
		
		spi_send_recv(0x0);
		spi_send_recv(0x10);
		
		DISPLAY_CHANGE_TO_DATA_MODE;
		
		for(j = 0; j < 16; j++) {
			c = textbuffer[i][j];
			if(c & 0x80)
				continue;
			
			for(k = 0; k < 8; k++)
				spi_send_recv(font[c*8 + k]);
		}
	}
}




void clear_display_buffer(void) {
    int i, j;
   
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 16; j++) {
            textbuffer[i][j] = 0;
        }
    }
    
    display_update();
}


void clear_oled_display_buffer() 

 {
    for (int y = 0; y < DISPLAY_HEIGHT; y++) {
        for (int x = 0; x < DISPLAY_WIDTH; x++) {
            ds[y][x] = 0;
        }
    }
}


void set_display_pixel(int x, int y) {
    if (x >= 0 && x < DISPLAY_WIDTH && y >= 0 && y < DISPLAY_HEIGHT) {
        ds[y][x] = 1;  
    } 
}



// LAB 3 for display_update
void update_oled_display() {
    for (int p = 0; p < DISPLAY_HEIGHT / 8; p++) {
        DISPLAY_CHANGE_TO_COMMAND_MODE;
        spi_send_recv(0x22);
        spi_send_recv(p);

        spi_send_recv(0x00); 
        spi_send_recv(0x10); 

        DISPLAY_CHANGE_TO_DATA_MODE;

        for (int col = 0; col < DISPLAY_WIDTH; col++) {
            uint8_t pixel_state = 0;
            for (int bit = 0; bit < 8; bit++) {
                int start_row = p * 8; 
                int current_pixel_row = start_row + bit; 

                if (ds[current_pixel_row][col] != 0) {
                   
                    pixel_state |= (1 << bit); 
                }
            }
            spi_send_recv(pixel_state);
        }
    }
}



void create_first_kobra(){
    int x = 64; 
    int y = 16; 
    kobra_length = 7;
    dx = 1;
    dy = 0;

    for (int i = 0; i < kobra_length; i++) {
        kobra_x[i] = x - i;
        kobra_y[i] = y;
    }
}

void automate_kobra_move() {
int px = kobra_x[0];
int py = kobra_y[0];

kobra_x[0] += dx; 
kobra_y[0] += dy; 


for (int i = 1; i < kobra_length; i++) {
    
    int tempX = kobra_x[i];
    int tempY = kobra_y[i];

    
    kobra_x[i] = px;
    kobra_y[i] = py;

    
    px = tempX;
    py = tempY;
    }
}

void handle_kobra_movement() {
    int bt = getbtns();

    int control[4][2] = {
        {1, 0},   
        {0, 1},   
        {0, -1},  
        {-1, 0}   
    };

    int pressed_button = 0;
    if (bt & 0x8) {     // BTN1 is pressed
        pressed_button = 1;
    } else if (bt & 0x1) {  // BTN2 is pressed
        pressed_button = 2;
    } else if (bt & 0x2) {  // BTN3 is pressed
        pressed_button = 3;
    } else if (bt & 0x4) {  // BTN4 is pressed
        pressed_button = 4;
    }

    
    if (pressed_button > 0 && pressed_button <= 4) {
        
        int ndx = control[pressed_button - 1][0];
        int ndy = control[pressed_button - 1][1];

        
        if (ndx != -dx || ndy != -dy) {
            
            dx = ndx;
            dy = ndy;
        }
    }
}



bool check_kobra_collision() {
    
    if (kobra_x[0] >= DISPLAY_WIDTH || kobra_x[0] <= 0 || kobra_y[0] >= DISPLAY_HEIGHT || kobra_y[0] <= 0) {
        return true; 
    }

    
    for (int i = 1; i < kobra_length; i++) {
        if (kobra_x[0] == kobra_x[i] && kobra_y[0] == kobra_y[i]) {
            return true; 
        }
    }
    
    return false; 
}


void handle_apple_collision(int *apple_x, int *apple_y) {
    
    if (kobra_x[0] == *apple_x && kobra_y[0] == *apple_y) {
        
        points++;
        kobra_length++;
        *apple_x = random_x();
        *apple_y = random_y();
    }
}



void display_points() {
    char points_str[2]; 
    
    points_str[0] = 48 + (points / 10);
    points_str[1] = 48 + (points % 10);
    display_string(2, points_str);

}


int s1 = 1;
int s2 = 1;

int random_x() {
    s1 = (s1 * 1103515245 + 12345) & 0x7FFFFFFF; 
    return (s1 % 125) + 1;
}


int random_y() {
    s2 = (s2 * 1664525 + 1013904223) & 0x7FFFFFFF;
    return (s2 % 29) + 1;
}
